**¿Qué es?**
Server-Side Template Injection es una vulnerabilidad que ocurre cuando una aplicación web permite que la entrada de un usuario se inserte de forma insegura dentro de una plantilla que es procesada por un servidor, en lugar de tratarlo como texto lo interpreta como código.



