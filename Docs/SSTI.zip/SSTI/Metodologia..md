![[serverside.png]]

Antes de realizar este tipo inyección, debemos saber que lenguaje de programación trata por detrás, por eso tendremos que observar bien en busca de lineal de código claves.

Ya que hay payloads específicos para cada lenguajes, como puede ser Asp, Java, JavaScript, PHP, Python, Ruby.

1.  Identificar parámetros reflejados en la respuesta del servidor.
2.  Probar con inyecciones básicas para ver el comportamiento de la web. por ejemplo {{7*7}}
3. Confirma si la web renderizado, en el caso de arriba tendría que aparecer 49.
4.  Y una vez confirmado el que es vulnerable, ya seria crear el payload/ exploit al gusto para buscar lo que queremos, con carpetas interesantes como puede ser system, os y demás.

Referencia: https://github.com/swisskyrepo/PayloadsAllTheThings/tree/master/Server%20Side%20Template%20Injection#methodology