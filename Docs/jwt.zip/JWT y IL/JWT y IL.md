**¿Qué es Json Web Token?**
Es un estándar para crear tokens de acceso que permiten transmitir información normalmente dedicado a la identidad y privilegios o claims entre partes de forma segura.


**¿Qué es Information Leakage?**
Se trata de una vulnerabilidad en la que un sistema, normalmente un servidor web, revela información, configuración o archivos que no deben. Esta exposición puede llevar consigo usuarios, información financiera, datos confidenciales y en general datos privados.

Referencias: 
https://i-networks.com.mx/que-son-los-data-breaches-y-data-leaks/
https://www.ibm.com/think/topics/data-leakage
https://portswigger.net/web-security/information-disclosure
