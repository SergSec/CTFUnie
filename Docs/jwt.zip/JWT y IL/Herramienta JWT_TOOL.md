Herramientas automatizada para agilizar la tarea de jwt.

```
git clone https://github.com/ticarpi/jwt_tool.git
```
el comando seria: `python3 jwt_tool.py tarjet`
