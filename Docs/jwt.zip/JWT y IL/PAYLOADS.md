Claim manipulado:

`{`
  `"role": "admin"`
`}`

Probar validación de seguridad razonable.

`{`
  `"exp": 9999999999`
`}`

Probar roles:

`{`
  `"role": "admin"`
`}`

Campos inesperados:

`{`
  `"unexpected": "value_test"`
`}`
