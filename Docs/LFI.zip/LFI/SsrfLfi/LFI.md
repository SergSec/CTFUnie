Local File Inclusión es una vulnerabilidad que permite incluir y leer archivos locales del server web.

**Ejemplo:** 
La aplicación espera cargar un archivo, por ejemplo:
`index.php?page=home.php`
Pero si no valida bien el parámetro, un atacante puede cambiarlo por algo como:
`index.php?page=../../../../etc/passwd`


<u>Metodología.</u>
**Descubrimiento:** Encontrar un parámetro vulnerable (ej. `?page=`, `?file=`, `?lang=`).
**Verificación:** Confirmar la vulnerabilidad con un path traversal básico (`../../../etc/passwd`).

Archivos interesantes a enumerar.

 **Info de usuarios:** 
```
/etc/passwd
```

**Hashes de contraseñas:** 
```
/etc/shadow
```

**Versión del SO:** 
```
/etc/issue
```

**Grupos del sistema:** 
```
/etc/group
```

**Nombre de host:** 
```
/etc/hostname
```

**Versión del kernel:** 
```
/proc/version
```

#### Configuraciones y Credenciales

**Credenciales de la app:** 
```
/var/www/html/config.php
```

**Credenciales de WordPress:** 
```
/var/www/html/wp-config.php
```

**Configuración cliente SSH:**
```
/etc/ssh/ssh_config
```

**Configuración servidor SSH:** 
```
/etc/ssh/sshd_config
```

**Clave privada SSH root:** 
```
/root/.ssh/id_rsa
```

**Claves autorizadas de root:** 
```
/root/.ssh/authorized_keys
```

**Claves de usuario:** 
```
/home/user/.ssh/id_rsa
```

```
/home/user/.ssh/authorized_keys
```

Herramientas automatizadas:
**LFISuite** : Herramienta automatizada para escanear y explotar vulnerabilidades LFI. Permite obtener shells remotos y probar múltiples payloads (https://github.com/D35m0nd142/LFISuite)


Referencias.
https://evi1us3r.wordpress.com/lfi-cheat-sheet/
https://github.com/RoqueNight/LFI---RCE-Cheat-Sheet
https://cheatography.com/binca/cheat-sheets/command-inj-lfi-rfi-and-directory-traversal/
https://www.exploit-db.com/docs/english/40992-web-app-penetration-testing---local-file-inclusion-(lfi).pdf
https://github.com/swisskyrepo/PayloadsAllTheThings/tree/master/File%20Inclusion





